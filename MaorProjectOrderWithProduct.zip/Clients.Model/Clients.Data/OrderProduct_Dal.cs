﻿using Clients.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clients.Data
{
    public class OrderProduct_Dal
    {
        const string TABLE_NAME = "Table_OrderProduct";
        public static async Task Insert(OrderProduct curOrderProduct)
        {
            string sql = "INSERT INTO Table_OrderProduct ([Order],[Product],[Quantity],[Price]) VALUES(@OrderId, @ProductId,@Quantity,@Price)";

            await Dal.ExecuteSql(sql, new { OrderId = curOrderProduct.Order.Id, ProductId = curOrderProduct.Product.Id, curOrderProduct.Quantity,curOrderProduct.Price });
        }
        public static async Task Insert(List<OrderProduct> curOrderProducts)
        {
            foreach (OrderProduct curOrderProduct in curOrderProducts) await Insert(curOrderProduct);
        }
    }
}

