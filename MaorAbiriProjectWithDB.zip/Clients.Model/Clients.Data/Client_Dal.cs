﻿using Clients.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clients.Data
{
    public class Client_Dal
    {
        public static async Task<IEnumerable<Client>> GetAll()
        {
            // The SQL query to select all clients
            string sql = "SELECT * FROM Table_Client";
            // Execute the query and retrieve the data - using the Dal class
            var clients = await Dal.QuerySql<Client>(sql);
            // Return the list of clients
            return clients;
        }
        public static async Task Add(Client curClient)
        {
            string sql = "INSERT INTO Table_Client (FirstName, LastName, BirthYear,Gender,Email) VALUES(@FirstName, @LastName, @BirthYear,@Gender,@Email)";

            await Dal.ExecuteSql(sql, new{curClient.FirstName,curClient.LastName,curClient.BirthYear,curClient.Gender,curClient.Email});

        }
        public static async Task Update(int id, Client curClient)
        {
            string sql = "UPDATE Table_Client SET FirstName = @FirstName, LastName =@LastName, BirthYear = @BirthYear, Gender =@Gender,Email=@Email  WHERE Id = @Id";
            await Dal.ExecuteSql(sql, new{curClient.FirstName,curClient.LastName,curClient.BirthYear,curClient.Gender,curClient.Email,id});
        }

        public static async Task Delete(int id)
        {
            string sql = "DELETE FROM Table_Client WHERE Id = @Id";
            await Dal.ExecuteSql(sql, new { Id = id });
        }
    }
}
