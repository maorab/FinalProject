﻿using Clients.Model;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Clients.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClientsController : ControllerBase
    {
        private static List<Client> clients = new List<Client>();
        private static void AddClients()
        {
            clients.Add(new Client(1, "Maor", "Abiri", 2006, "Male", "maorab2006@gmail.com"));
            clients.Add(new Client(2, "Noam", "Kedmi", 2007, "Male", "Noamk@gmail.com"));
            clients.Add(new Client(2, "No", "Choen", 2000, "FeMale", "NoaC@gmail.com"));
            clients.Add(new Client(2, "Yaniv", "Ranim", 2001, "Male", "YanivRR@gmail.com"));
            clients.Add(new Client(2, "Armin", "Yeager", 2010, "Male", "ArmYer@gmail.com"));
        }
        static ClientsController()
        {
            AddClients();
        }
        // GET: api/<ClientsController>
        [HttpGet]
        public IEnumerable<Client> Get()
        {
            return clients;
        }

        // GET api/<ClientsController>/5
        [HttpGet("{id}")]
        public Client? Get(int id)
        {
            foreach (Client client in clients)
            {
                if (client.Id == id)
                    return client;
            }
            return null;
        }

        // POST api/<ClientsController>
        [HttpPost]
        public void Post([FromBody] Client curclient)
        {
            clients.Add(new Client(clients.Count+1, curclient.FirstName, curclient.LastName, curclient.BirthYear, curclient.Gender
                , curclient.Email));
        }

        // PUT api/<ClientsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Client curclient)
        {
            foreach (Client client in clients)
            {
                if (client.Id == curclient.Id)
                {
                    client.FirstName = curclient.FirstName;
                    client.LastName = curclient.LastName;
                    client.BirthYear = curclient.BirthYear;
                    client.Gender = curclient.Gender;
                    client.Email = curclient.Email;
                    return;

                }
            }
        }

        // DELETE api/<ClientsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            foreach (Client client in clients)
                if (client.Id == id)
                {
                    clients.Remove(client);
                    return;
                }
        }
    }
}
