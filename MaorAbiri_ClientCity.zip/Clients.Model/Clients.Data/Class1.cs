﻿namespace Clients.Data
{
    public class Class1
    {

    }
}
