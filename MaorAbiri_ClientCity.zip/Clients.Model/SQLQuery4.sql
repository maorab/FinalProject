﻿ALTER TABLE Table_Client
ADD City INT;