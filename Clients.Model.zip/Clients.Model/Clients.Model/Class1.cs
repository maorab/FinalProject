﻿namespace Clients.Model
{
    public class Class1
    {

    }
}
